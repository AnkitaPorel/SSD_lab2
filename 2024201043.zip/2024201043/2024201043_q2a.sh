#!/bin/bash
num=$1
a=0
b=1
if [ $num = "1" ]
then
printf "$a "
elif [ $num = "2" ]
then
printf "$a $b "
elif [ $num -gt 2 ];
then
printf "$a $b "
for ((i=2 ; i<$num ; i++))
do
	c=$((a+b))
	printf "$c "
	a=$b
	b=$c
done
fi
echo
