#!/bin/bash
if [ -z $A ] || [ -z $B ]
then
	echo "You need to set the environment variables A and B."
	exit 1
else 
sum=$((A+B))
echo "Sum= $sum"
fi
