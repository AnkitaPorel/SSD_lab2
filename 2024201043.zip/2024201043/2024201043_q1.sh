#!/bin/bash
file_found=$(locate -i "$1")
head -n 4 $file_found
