Q1. 2024201043_q1.sh

This script is for bash. 
The script uses locate command to locate a file named "john_doe_assignment.txt", file name has to passed as a command line input. 
The file found using locate command is stored in a variable "file_found". Then head command is used to print first 4 lines of the file.
To execute- ./2024201043_q1.sh john_doe_assignment.txt

Q2. (a) 2024201043_q2a.sh

This script is for bash. 
The script takes a integer as command line input. Then the script prints that specific numbers in a Fibonacci series.
The script uses for loop to calculate and print the series.
To execute- ./2024201043_q2a.sh 10

Q2. (b) 2024201043_q2b.sh

This script is for bash. 
This script requires two environment variables named A and B.
So, before executing this, execute the following in shell-
export A=7
export B=19
To execute- ./2024201043_q2b.sh
